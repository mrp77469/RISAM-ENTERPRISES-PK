RISAM ENTERPRISES - CPANEL DEPLOYMENT

1. Upload all files in this folder to public_html (or your chosen document root).
2. Keep index.html and send-mail.php in the same folder.
3. The meeting form sends enquiries to: risamenterprises.pk@gmail.com
4. PHP mail() must be enabled by your hosting provider.
5. For best deliverability, create website@your-domain.com in cPanel if possible.
6. Test the Request a Meeting form after uploading.

CEO image is embedded inside index.html, so no separate CEO image file is required.
Some non-CEO website imagery is loaded from Unsplash and requires internet access.
