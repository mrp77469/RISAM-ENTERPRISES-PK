<?php
// RISAM Enterprises - cPanel meeting enquiry endpoint
// Upload this file in the same folder as index.html.
header('Content-Type: application/json; charset=UTF-8');

const RECIPIENT = 'risamenterprises.pk@gmail.com';
const SITE_NAME = 'RISAM Enterprises';

function respond(bool $success, string $message, int $status = 200): void {
    http_response_code($status);
    echo json_encode(['success' => $success, 'message' => $message], JSON_UNESCAPED_SLASHES);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(false, 'Invalid request method.', 405);
}

// Honeypot: bots that fill this hidden field are rejected silently.
if (!empty($_POST['website'] ?? '')) {
    respond(true, 'Thank you.');
}

function clean(string $value, int $max = 1000): string {
    $value = trim(str_replace(["\r", "\n"], ' ', $value));
    return mb_substr($value, 0, $max);
}

$name = clean((string)($_POST['fullName'] ?? ''), 120);
$company = clean((string)($_POST['company'] ?? ''), 160);
$email = trim((string)($_POST['email'] ?? ''));
$phone = clean((string)($_POST['phone'] ?? ''), 60);
$service = clean((string)($_POST['service'] ?? ''), 100);
$date = clean((string)($_POST['preferred_date'] ?? ''), 30);
$time = clean((string)($_POST['preferred_time'] ?? ''), 30);
$message = trim((string)($_POST['message'] ?? ''));
$message = mb_substr($message, 0, 3000);

if ($name === '' || $email === '' || $phone === '' || $service === '') {
    respond(false, 'Please complete all required fields.', 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    respond(false, 'Please enter a valid email address.', 422);
}

$allowedServices = [
    'Cybersecurity', 'E-Commerce', 'Digital Marketing', 'Web Development',
    'Business Consultancy', 'E-Commerce Store', 'Other'
];
if (!in_array($service, $allowedServices, true)) {
    respond(false, 'Please select a valid service.', 422);
}

// Basic per-IP rate limit using a temporary file. cPanel PHP normally permits this.
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$rateFile = sys_get_temp_dir() . '/risam_' . hash('sha256', $ip) . '.txt';
$now = time();
if (is_file($rateFile)) {
    $last = (int)@file_get_contents($rateFile);
    if ($last > 0 && ($now - $last) < 45) {
        respond(false, 'Please wait a moment before sending another request.', 429);
    }
}
@file_put_contents($rateFile, (string)$now, LOCK_EX);

$subject = 'New Meeting Request - ' . $service . ' | ' . $name;
$body = "New meeting request received from the RISAM Enterprises website.\n\n" .
        "Full Name: {$name}\n" .
        "Company / Business: " . ($company !== '' ? $company : 'Not provided') . "\n" .
        "Email: {$email}\n" .
        "Phone: {$phone}\n" .
        "Service: {$service}\n" .
        "Preferred Date: " . ($date !== '' ? $date : 'Not specified') . "\n" .
        "Preferred Time: " . ($time !== '' ? $time : 'Not specified') . "\n\n" .
        "Message / Requirements:\n" . ($message !== '' ? $message : 'Not provided') . "\n\n" .
        "Submitted from: " . ($_SERVER['HTTP_HOST'] ?? 'RISAM website') . "\n";

// Use a domain-based From address for better cPanel mail deliverability.
$domain = preg_replace('/[^a-z0-9.-]/i', '', $_SERVER['HTTP_HOST'] ?? '');
$fromDomain = $domain !== '' ? $domain : 'risamenterprises.pk';
$from = 'website@' . $fromDomain;
$headers = [
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'From: ' . SITE_NAME . ' Website <' . $from . '>',
    'Reply-To: ' . $email,
    'X-Mailer: PHP/' . PHP_VERSION
];

$sent = @mail(RECIPIENT, $subject, $body, implode("\r\n", $headers));

if (!$sent) {
    respond(false, 'The server could not send the email. Please call or WhatsApp RISAM Enterprises.', 500);
}

respond(true, 'Your meeting request has been sent successfully.');
